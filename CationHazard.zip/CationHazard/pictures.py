import pygame


class Pictures:
    def __init__(self):
        self.logo = pygame.image.load("materials/pictures/logo/logo.ico")
        self.background = pygame.image.load("materials/pictures/background/bgbg.jpg")


