import pygame
import random

print(random.randint(3, 5))
