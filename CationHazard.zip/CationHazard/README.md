# CationHazard
 C language project \
Group member: 史绍康 陈柄璋 王晨竹

2021年，随着20级唐班C语言项目作业的开启，
水溶液中阴离子与阳离子之间的矛盾也不断升级，
阳离子大军企图消灭阴离子。 
我们需要帮助阴离子阻止阳离子大军的入侵。
